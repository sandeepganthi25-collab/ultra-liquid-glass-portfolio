# Ganthi Sai Sandeep — Ultra Liquid Glass Portfolio

Premium responsive portfolio using HTML5 and CSS3 only. The UI uses layered liquid-glass surfaces, backdrop blur and saturation, specular highlights, iridescent cyan/blue/violet edges, atmospheric lighting, refined card depth, hover lift, shimmer accents, and mobile-responsive layouts. The profile photo section remains clean without floating information boxes.

## Files
- `index.html` — portfolio content and semantic structure
- `style.css` — complete visual system, liquid-glass effects, animations and responsive styles
- `images/profile.jpg` — profile photo
- `project-description.txt` — internship submission summary

## Run locally
Extract the ZIP and open `index.html` in a modern browser. Keep `index.html`, `style.css`, and `images/` together.

HTML5 and CSS3 only; no JavaScript or UI frameworks. Browsers without backdrop-filter use a darker opaque fallback.
